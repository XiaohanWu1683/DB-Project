<?php
    require_once('connection.php');
    session_start();
    $_SESSION['push_flag'] = false;
    $company_id = $_SESSION['company_id'];
    $company_name = $_SESSION['company_name'];
    $msg = '';
?>

<?php
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    if (isset($_POST['submit']))
    { 
        
        if (!empty($_POST['registercompanypassword']) && !empty($_POST['registercompanyname']))
        {
            $company_name = mysqli_real_escape_string($dbc, trim($_POST['registercompanyname']));
            $company_password = mysqli_real_escape_string($dbc, trim($_POST['registercompanypassword']));
            $_SESSION['company_name'] = $company_name;
            if (!empty($_POST['registercompanylocation']))
                $company_location = mysqli_real_escape_string($dbc, trim($_POST['registercompanylocation']));

            if (!empty($_POST['registercompanyindustry']))
                $industry = mysqli_real_escape_string($dbc, trim($_POST['registercompanyindustry']));
            else 

            if (!empty($_POST['registercompanydes']))
                $company_description = mysqli_real_escape_string($dbc, trim($_POST['registercompanydes']));  
            
            $query = 
            "UPDATE Company " . 
            "SET " .  
            "company_name = '$company_name', " . 
            "company_password = SHA('$company_password'), " . 
            "company_location = '$company_location', " . 
            "industry = '$industry', " . 
            "company_description = '$company_description' " . 
            "WHERE company_id = $company_id; "; 
            $data = mysqli_query($dbc, $query);

            $msg = 'update success!';
        }
        else 
        {   
            echo 'Company Name and Password cannot be empty';
        }
    }
?>





<!-- 公司，edit -->




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Jobster Company Edit</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>

        #topContainer
        {
            background-image: url("images/companybackground.jpg");
            height:975px;
            width:100%;
            background-size:cover;
        }
        #informationRow
        {
            margin-top:100px;
        }
        #informationform
        {
            margin-top:20px;
        }

        .whiteBackground
        {
            margin-right:10px;
            padding:20px;
            background-color: hsla(240, 20%, 95%, 0.8);
            border-radius: 20px;
        }

    </style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" id="topBar">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarlink" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
				<span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbarlink">
            <ul class="nav navbar-nav ">
                <li class="active"><a href="companyhome.php">Company Homepage<span class="sr-only">(current)</span></a></li>
                <li><a href="jobspost.php">Jobs</a></li>
				<li><a href="companymessagepage.php">Messages</a></li>
                <li><a href="studentsearch.php">Students</a></li>
            </ul>

            <form class="navbar-form navbar-right" action="logout.php" method="post">

			
                <font color=white>  <?php echo $company_name; ?> </font>

				
			<input type="submit" class="btn btn-success" name="submit" value="Log out"/> <!-- 这地方直接退出登录了 返回主界面 -->
            </form>

        </div>
    </div>
</nav>


<div class="container" id="topContainer">
    <div class="row" id="informationRow">
        <div class="col-md-4 col-md-offset-1 whiteBackground" id="informationform">

			<form method="post">

                <div class="form-group">
                    <label for="registercompanypassword">Company Name <font color=red> * </font>:</label>
                    <input type="text" class="form-control" placeholder="Company Name" name="registercompanyname" id="registercompanyname"/>
                </div>

                <div class="form-group">
                    <label for="registercompanypassword">Password <font color=red> * </font>:</label>
                    <input type="password" class="form-control" placeholder="Password" name="registercompanypassword" id="registercompanypassword"/>
                </div>
				
				<div class="form-group">
                    <label for="registercompanylocation">Company Location:</label>
                    <input type="text" class="form-control" placeholder="Company Location" name="registercompanylocation" id="registercompanylocation"/>
                </div>
				
				<div class="form-group">
                    <label for="registercompanyindustry">Company Industry:</label>
                    <input type="text" class="form-control" placeholder="Company Industry" name="registercompanyindustry" id="registercompanyindustry"/>
                </div>
				
				<div class="form-group">
                    <label for="registercompanydes">Company Description:</label>
                    <input type="text" class="form-control" placeholder="Company Description" name="registercompanydes" id="registercompanydes"/>
                    <!-- <p>
                        <textarea cols="80" rows="4" wrap="hard" id="story" name="story">
                        </textarea>
                    </p> -->
                </div>
				
				<input type="submit" class="btn btn-success" name="submit" value="Submit"/>
			</form>
        </div>
    </div>
</div> 

</body>
</html>



<?php echo $msg; ?>
<?php
    session_start();
    if (isset($_SESSION['student_id']) || isset($_SESSION['company_id']))
    {
        $_SESSION = array();
        session_destroy();
        // echo '<p> back to login page in 5 secs </p>';
        // sleep(5);
        $home_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/index.php';
        header('Location: ' . $home_url);
    }
?>
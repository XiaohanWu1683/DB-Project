
<?php
    require_once('connection.php');
    session_start();
    $company_id = $_SESSION['company_id'];
    $company_name = $_SESSION['company_name'];
?>


<!-- Student search 公司 -->




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Students Search</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>

        #topContainer
        {
            background-image: url("images/companybackground.jpg");
            height:975px;
            width:100%;
            background-size:cover;
        }

        #informationRow
        {
            margin-top:100px;
        }
        #informationform
        {
            margin-top:20px;
        }
		
		#resultform
        {
			margin-top:-200px;
			margin-left:1000px;
		}

        .whiteBackground{
            margin-right:10px;
            padding:20px;
            background-color: hsla(240, 20%, 95%, 0.8);
            border-radius: 20px;
        }

    </style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" id="topBar">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarlink" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
				<span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbarlink">
            <ul class="nav navbar-nav ">
                <li><a href="companyhome.php">Company Homepage</a></li>
                <li><a href="jobspost.php">Jobs</a></li>
				<li><a href="companymessagepage.php">Messages</a></li>
                <li  class="active"><a href="studentsearch.php">Students<span class="sr-only">(current)</span></a></li>
            </ul>

            <form class="navbar-form navbar-right" action="logout.php" method="post">

			
                <?php echo '<font color=white>' . $company_name . '</font>'; ?>

				
			<input type="submit" class="btn btn-success" name="submit" value="Log out"/> <!-- 这地方直接退出登录了 返回主界面 -->
            </form>

        </div>
    </div>
</nav>


<div class="container" id="topContainer">
    <div class="row" id="informationRow">
        <div class="col-md-4 col-md-offset-1 whiteBackground" id="informationform">
		
			<form method="post" action="studentsearch.php">
			<h3>Search student</h3>
			
				<div class="form-group">
                    <label for="studentname">Student Name:</label>
                    <input type="text" class="form-control" placeholder="Please enter student name" name="studentname" id="studentname"/>
                </div>
				
				<div class="form-group">
                    <label for="studentmajor">Student Major:</label>
                    <input type="text" class="form-control" placeholder="Please enter student major" name="studentmajor" id="studentmajor"/>
                </div>

				<div class="form-group">
                    <label for="studentuniver">Student University:</label>
                    <input type="text" class="form-control" placeholder="Please enter student university" name="studentuniver" id="studentuniver"/>
                </div>
				
				<div class="form-group">
                    <label for="studentgpa">Student GPA:</label> <br/>
                    <input type="float" name="gpal" id="gpal" value=0.0 />
                    <label for="studentgpa">-</label>
                    <input type="float" name="gpar" id="gpar" value=0.0 />
                </div>
				
				<div class="form-group">
                    <label for="studentresume">Student Resume:</label>
                    <input type="text" class="form-control" placeholder="Please enter student resume keywords" name="studentresume" id="studentresume"/>
                </div>
				
				<input type="submit" class="btn btn-success" name="submit" value="Search"/>
			</form>

        </div>
    </div>
	
	<br/>
	
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 whiteBackground">
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-hover">
					<tbody>
		
        <?php
            if (isset($_POST['submit']) && $_POST['submit'] == 'Push')
            {
                $job_id = $_POST['job_id'];
                $_SESSION['push_flag'] = true;
                $_SESSION['job_id'] = $_POST['job_id'];
            }


            if (isset($_POST['submit']) && $_POST['submit'] == 'Search')
            {
                $student_name = $_POST['studentname'];
                $major = $_POST['studentmajor'];
                $university = $_POST['studentuniver'];
                $gpal = $_POST['gpal'];
                $gpar = $_POST['gpar'];
                $resume = $_POST['studentresume'];
                $_SESSION['push_list'] = array();

                $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
                $query = 
                "SELECT * FROM Student WHERE ";

                if (!empty($student_name))
                    $query = $query . "student_name = '$student_name' AND ";
                if (!empty($major))
                    $query = $query . "major = '$major' AND ";
                if (!empty($university))
                    $query = $query . "university = '$university' AND ";
                if (!empty($resume))
                    $query = $query . "resume LIKE '%$resume%' AND ";
                if (!($gpal == 0 && $gpar == 0))
                    $query = $query . "gpa between $gpal AND $gpar AND ";
                $query = $query . "True;";

                $data = mysqli_query($dbc, $query);

                if (mysqli_num_rows($data))
                {
                    echo '<thead><tr>';
                    echo '<th> Name </th>';
                    echo '<th> Email </th>';
                    echo '<th> Major </th>';
                    echo '<th> University </th>
					<th> Action </th></tr></thead>';
                    while ($record = mysqli_fetch_array($data))
                    {
                        echo '<tr>';
                        echo '  <td>' . $record['student_name'] . '</strong> </td>';
                        echo '  <td>' . $record['student_email'] . '</td>';
                        echo '  <td>' . $record['major'] . '</td>';
                        echo '  <td>' . $record['university'] . '</td>';
                        echo '  <td>';
                        echo '      <form method="post" action="companyViewStudent.php">';
                        echo '      <input type="submit" class="btn btn-success" name="submit" value="Details"/>';
                        echo '      <input type="hidden" name="student_id" value=' . $record['student_id'] . '>';
                        echo '      </form>';
                        echo '  </td>';
                        echo '</tr>';
                        array_push($_SESSION['push_list'], $record['student_id']);
                    }
                }
                
                // print_r($_SESSION['push_list']);
                if ($_SESSION['push_flag'] && count($_SESSION['push_list']))
                {
                    echo '<form method="POST" action="studentsearch.php">';
                    echo '<input type="submit" class="btn btn-success" name="submit" value="Send" />';
                    echo '</form>';
                }

				mysqli_close($dbc);

            }
            else if (isset($_POST['submit']) && $_POST['submit'] == 'Send')
            {   
                $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
                $job_id = $_SESSION['job_id'];
                foreach ($_SESSION['push_list'] as $student_id)
                {
                    $query = 
                    "INSERT INTO Announcement (student_id, job_id, announce_time) " . 
                    "VALUES ($student_id, $job_id, NOW());";
                    mysqli_query($dbc, $query);
                }
                echo '<h3> Job Announcement Sent. </h3>';
                mysqli_close($dbc);
                $_SESSION['push_list'] = array();
                $_SESSION['push_flag'] = false;
            }
           
            
        ?>

        <!-- process job push operation -->
        <?php

        ?>     
					</tbody>
				</table>
			</div>
        </div>
    </div>
</div>

</body>
</html>
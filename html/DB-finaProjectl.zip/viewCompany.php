<?php
    require_once('connection.php');
    session_start();
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Students Details</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>

        #topContainer
        {
            background-image: url("images/companybackground.jpg");
            height:975px;
            width:100%;
            background-size:cover;
        }

        #informationRow
        {
            margin-top:100px;
        }
        #informationform
        {
            margin-top:20px;
        }
		
		#resultform
        {
			margin-top:-200px;
			margin-left:1000px;
		}

        .whiteBackground{
            margin-right:10px;
            padding:20px;
            background-color: hsla(240, 20%, 95%, 0.8);
            border-radius: 20px;
        }

    </style>
</head>
<body>
<div class="container" id="topContainer">
    <div class="row" id="informationRow">
		<div class="col-md-6 col-md-offset-1 whiteBackground" id="informationform">
        <?php
            if (isset($_POST['submit']))
            {
                if (isset($_POST['company_id']))
                {
                    $company_id = $_POST['company_id'];
                    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
                    
                    $query = 
                    "SELECT * " .
                    "FROM Company " . 
                    "WHERE company_id = $company_id; ";

                    $data = mysqli_query($dbc, $query);
                    $record = mysqli_fetch_array($data);

                    echo '<strong> Name: </strong>' . $record['company_name'] . '<br/>';
                    echo '<strong> Email: </strong>' . $record['company_email'] . '<br/>';
                    echo '<strong> Location: </strong>' . $record['company_location'] . '<br/>';
                    echo '<strong> Industry: </strong>' . $record['industry'] . '<br/>';
                    echo '<strong> Description: </strong>' . $record['company_description'] . '<br/>';

                    // echo '<strong> Resume: </strong> <br/>' . $record['resume'] . '<br/>';
                }

                mysqli_close($dbc);
                
            }
        ?>
        <a href="followedcompany.php"> << Back </a>
		</div>
	</div>
</div>

</body>
</html>
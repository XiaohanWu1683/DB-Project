<?php
    require_once('connection.php');
    session_start();
    $_SESSION['push_flag'] = false;
    $company_id = $_SESSION['company_id'];
    $company_name = $_SESSION['company_name'];
?>


<!-- Messages 公司 -->




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Company Messages</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>

        #topContainer
        {
            background-image: url("images/companybackground.jpg");
            height:975px;
            width:100%;
            background-size:cover;
        }

        #informationRow
        {
            margin-top:100px;
        }
        #informationform
        {
            margin-top:20px;
        }
		
		#resultform
        {
			margin-top:-600px;
			margin-left:1000px;
		}

        .whiteBackground
        {
            margin-right:10px;
            padding:20px;
            background-color: hsla(240, 20%, 95%, 0.8);
            border-radius: 20px;
        }

    </style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" id="topBar">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarlink" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
				<span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbarlink">
            <ul class="nav navbar-nav ">
                <li><a href="companyhome.php">Company Homepage</a></li>
                <li><a href="jobspost.php">Jobs</a></li>
				<li  class="active"><a href="companymessagepage.php">Messages<span class="sr-only">(current)</span></a></li>
                <li><a href="studentsearch.php">Students</a></li>
            </ul>

            <form class="navbar-form navbar-right" action="logout.php" method="post">

			
                <font color=white>  <?php echo $company_name; ?> </font>

				
			<input type="submit" class="btn btn-success" name="submit" value="Log out"/> <!-- 这地方直接退出登录了 返回主界面 -->
            </form>

        </div>
    </div>
</nav>


<div class="container" id="topContainer">
    <div class="row" id="informationRow">
        <div class="col-lg-12 col-md-12 col-sm-12 whiteBackground">
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-hover">
					<tbody>	


            <!-- PHP starts -->
            <!-- Display all applications -->

            <?php
                $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
                $query = 
                "SELECT COUNT(*) AS unread " .
                "FROM Job NATURAL JOIN Company NATURAL JOIN Application NATURAL JOIN Student " .  
                "WHERE company_id = $company_id; ";

                $data = mysqli_query($dbc, $query);
                $record = mysqli_fetch_array($data);
                $unread = $record['unread'];
                echo "<h4> Applications ($unread) </h4>";


                $query = 
                "SELECT * FROM " . 
                "Job NATURAL JOIN Company NATURAL JOIN Application NATURAL JOIN Student " .  
                "WHERE company_id = $company_id; ";

                $data = mysqli_query($dbc, $query);
                echo '<thead><tr>';
                echo '<th> Title </th>';
                echo '<th> Requirement </th>';
                echo '<th> Job Location </th>';
                echo '<th> Salary </th>';
                echo '<th> Applicant Name </th>';
                echo '<th> Applicant Email </th>';
                echo '<th> Applicant Major </th>';
                echo '<th> Applicant GPA </th>';
                echo '<th> Application Time </th>
					  <th> Action</th>
				</tr></thead>';
                if (mysqli_num_rows($data))
                {
                    while ($record = mysqli_fetch_array($data))
                    {
                        echo '<tr>';
                        if (!$record['apply_status'])
                        {
                            echo '<td> <strong>' . $record['title'] . '</strong> </td>';
                            echo '<td> <strong>' . $record['background_req'] . '</strong> </td>';
                            echo '<td> <strong>' . $record['job_location'] . '</strong> </td>';
                            echo '<td> <strong>' . $record['salary'] . '</strong> </td>';
                            echo '<td> <strong>' . $record['student_name'] . '</strong> </td>';
                            echo '<td> <strong>' . $record['student_email'] . '</strong> </td>';
                            echo '<td> <strong>' . $record['major'] . '</strong> </td>';
                            echo '<td> <strong>' . $record['gpa'] . '</strong> </td>';
                            echo '<td> <strong>' . $record['apply_time'] . '</strong> </td>';
                        }
                        else
                        {
                            echo '<td> ' . $record['title'] . ' </td>';
                            echo '<td> ' . $record['background_req'] . ' </td>';
                            echo '<td> ' . $record['job_location'] . ' </td>';
                            echo '<td> ' . $record['salary'] . ' </td>';
                            echo '<td> ' . $record['student_name'] . ' </td>';
                            echo '<td> ' . $record['student_email'] . ' </td>';
                            echo '<td> ' . $record['major'] . ' </td>';
                            echo '<td> ' . $record['GPA'] . ' </td>';
                            echo '<td> ' . $record['apply_time'] . ' </td>';
                        }
                        echo '<td>';
                        echo '<form method="post" action="companyViewStudent.php">';
                        echo '<input type="submit" class="btn btn-success" name="submit" value="Details"/>';
                        echo '<input type="hidden" name="student_id" value=' . $record['student_id'] . '>';
                        echo '</form>';
                        echo '</td>';
						echo '<tr>';
                    }
                }
            ?>
		

            <!-- PHP ends -->
					</tbody>
				</table>
			</div>	
        </div>
    </div>
</div>

</body>
</html>
<?php
    session_start();
    require_once('connection.php');
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
?>


<?php
    if (isset($_POST['submit']) && $_POST['submit'] == 'Send')
    {
        // echo $_POST['submit'];
        // echo $_POST['msg_to'];
        $msg_to = $_POST['msg_to'];
        $content = $_POST['content'];
        if (!empty($content))
        {
            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
            $query = "INSERT INTO Message VALUES ($student_id, $msg_to, NOW(), '$content', 0)";
            echo $query;
            mysqli_query($dbc, $query);
            mysqli_close($dbc);
            echo 'Message Sent.';
        }
        
    }
?>  

<a href="friendpage.php"> << Back </a>
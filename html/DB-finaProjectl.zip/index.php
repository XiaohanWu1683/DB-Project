<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Jobster Students Homepage</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        #topContainer
        {
            background-image: url("images/back.jpeg");
            height:975px;
            width:100%;
            background-size:cover;
        }
        #registerRow
        {
            margin-top:200px;
        }
        #registerform
        {
            margin-top:20px;
        }
		#failform
        {
			margin-top:-550px;
			margin-left:1300px;
		}
        .whiteBackground
        {
            margin-right:10px;
            padding:20px;
            background-color: hsla(240, 20%, 95%, 0.8);
            border-radius: 20px;
        } 
        
    </style>
</head>
<body>


<nav class="navbar navbar-inverse navbar-fixed-top" id="topBar">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarlink" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
				<span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbarlink">
            <ul class="nav navbar-nav ">
                <li class="active"><a href="index.php">Students<span class="sr-only">(current)</span></a></li>
                <li><a href="indexcompany.php">Companies</a></li>
				<!-- <li><a href="about.php">About</a></li>
                <li><a href="Developer.php">Developer</a></li> -->
            </ul>

            <form class="navbar-form navbar-right" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Student Email" name="loginemail"/>
                </div>

                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" name="loginpassword"/>
                </div>
                <input type="submit" class="btn btn-success" name="login" value="login"/>
            </form>

        </div>
    </div>
</nav>



<div class="container" id="topContainer">
    <div class="row" id="registerRow">
        <div class="col-md-4 col-md-offset-1 whiteBackground" id="registerform">
			<h1> Student Register</h1>
            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      

                <div class="form-group">
                    <label for="registername">User Name:</label>
                    <input type="text" class="form-control" placeholder="User Name" name="registername" id="registername"/>
                </div>

                <div class="form-group">
                    <label for="registeremail">Email:(You will use it as login account)</label>
                    <input type="email" class="form-control" placeholder="Email" name="registeremail" id="registeremail"/>
                </div>

                <div class="form-group">
                    <label for="registerpassword">Password:</label>
                    <input type="password" class="form-control" placeholder="Password" name="registerpassword" id="registerpassword"/>
                </div>
                <input type="submit" class="btn btn-success" name="signup" value="signup"/>

            </form>

        </div>
    </div>
</div>


<div>

    <?php // sign in

        session_start();
        if (!isset($_SESSION["student_id"]))
        {
            require_once('connection.php');
            // clear error message
            $error_msg = '';
            if (isset($_POST['login']))
            {
                $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die('db connection error # 5');
                $login_emial = mysqli_real_escape_string($dbc, trim($_POST['loginemail']));
                $login_pasword = mysqli_escape_string($dbc, trim($_POST['loginpassword']));

                if (!empty($login_emial) && !empty($login_pasword))
                {
                    $query = 
                    "SELECT student_id, student_email, student_name " . 
                    "FROM Student " . 
                    "WHERE student_email = '$login_emial' AND student_password = SHA('$login_pasword'); ";

                    // echo $query;

                    $data = mysqli_query($dbc, $query);
                    if (mysqli_num_rows($data) == 1)
                    {
                        // valid email and pwd
                        $record = mysqli_fetch_array($data);
                        $_SESSION['student_id'] = $record['student_id'];
                        $_SESSION['student_email'] = $record['student_email'];
                        $_SESSION['student_name'] = $record['student_name'];

                        echo '<form name="front" action="studenthome.php" method="POST">';
                        echo '   <input type="hidden" name="student_id" value="' . $_SESSION['student_id'] . '">';
                        echo '</form>';
                        echo '<script type="text/javascript">';
                        echo '   document.front.submit();';
                        echo '</script>';

                    }
                    else $error_msg = 'Invalid email or pwd';
                }
                else $error_msg = 'Must enter email and pwd';
            }
        }
        else
        {
            echo '<form name="front" action="studenthome.php" method="POST">';
            echo '   <input type="hidden" name="student_id" value="' . $_SESSION['student_id'] . '">';
            echo '</form>';
            echo '<script type="text/javascript">';
            echo '   document.front.submit();';
            echo '</script>';
        }
    ?>




    <?php //sign up

        if (isset($_POST['signup']))
        {
            require_once('connection.php');
            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die('db connection error #3');

            $reigister_name = mysqli_real_escape_string($dbc, trim($_POST['registername']));
            $register_password = mysqli_real_escape_string($dbc, trim($_POST['registerpassword']));
            $register_email = mysqli_real_escape_string($dbc, trim($_POST['registeremail']));

            if (!empty($reigister_name) && !empty($register_password) && !empty($register_email))
            {
                $query = 
                "SELECT * FROM Student " . 
                "WHERE student_email = '$register_email' ";

                // echo $query;
                echo '</br>';

                $data = mysqli_query($dbc, $query);
                
                if (mysqli_num_rows($data) == 0)
                {
                    # email is unique
                    $query = 
                    "INSERT INTO Student (student_name, student_password, student_email) " . 
                    "VALUES ('$reigister_name', SHA('$register_password'), '$register_email'); ";
                    // echo $query;
                    mysqli_query($dbc, $query);
                    echo '<p> Welcome to Jobster! ';
                    echo 'You are now ready to log in. </p>';

                    mysqli_close($dbc);
                    exit();
                }
                else $error_msg = 'an account already occur.';
            }
            else $error_msg = 'critical data missing';
            mysqli_close($dbc);
        }

        // 

    ?>
</div>




<!-- 登录失败用 -->
<?php
if (!empty($error_msg))
{
?>
    <div class="row" id="informationRow">
        <div class="col-md-4 col-md-offset-1 whiteBackground" id="failform">
            <h3> <?php echo $error_msg ?> </h3>
        </div>
    </div>

<?php
}
$error_msg='';
?>


</body>
</html>

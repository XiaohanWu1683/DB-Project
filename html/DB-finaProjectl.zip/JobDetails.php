<?php
    session_start();
    require_once('connection.php');
    $student_id = $_SESSION['student_id'];
	$student_name = $_SESSION['student_name'];
	$job_id = $_POST['job_id'];
	echo $job_id;
?>

<!-- 学生主页，Homepage -->

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>home</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Jobster</a>
            </div>

            <div class="header-right">
				<!--显示未读消息数量-->
                <a href="studentjobnot.php" class="btn btn-info" title="New Jobs"><b>
					<?php
                        echo $_SESSION['jobs_unread'];
					?>
				</b><i class="fa fa-envelope-o fa-2x"></i></a>
				
				<!--显示未读消息数量-->
                <a href="studentfriendmes.php" class="btn btn-primary" title="New Messages"><b>
					<?php
                        echo $_SESSION['msg_unread'];
					?>
				</b><i class="fa fa-bars fa-2x"></i></a>
				
				<a href="logout.php" class="btn btn-danger" title="Logout"><i class="fa fa-exclamation-circle fa-2x"></i></a>
            </div>
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="assets/img/user.png" class="img-thumbnail" />

                            <div class="inner-text">
                                <?php
									echo '<font color = white>' . $_SESSION['student_name'] . '</font>';
								?>
                            <br />
                                <small>Student </small>
                            </div>
                        </div>

                    </li>


                    <li>
                        <a href="studenthome.php"><i class="fa fa-dashboard "></i>Home</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-yelp "></i>Message Box <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="studentfriendmes.php"><i class="fa fa-coffee"></i>Friend Messages</a>
                            </li>
                            <li>
                                <a href="studentjobnot.php"><i class="fa fa-flash "></i>Job Notification</a>
                            </li>
                             <li>
                                <a href="studentsent.php"><i class="fa fa-key "></i>Send</a>
                            </li>                           
                        </ul>
                    </li>
                    <li>
                        <a class="active-menu" href="jobsearch.php"><i class="fa fa-flash "></i>Job Search </a>
                        
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-bicycle "></i>Social <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                           
                             <li>
                                <a href="friendpage.php"><i class="fa fa-desktop "></i>Friends </a>
                            </li>
                             <li>
                                <a href="followedcompany.php"><i class="fa fa-code "></i>Followed Company</a>
                            </li>
                             
                           
                        </ul>
                    </li>
                      <li>
                        <a href="editstudent.php"><i class="fa fa-anchor "></i>Edit Profile</a>
                    </li>
					
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Job Details</h1>
                        <h1 class="page-subhead-line">Want more information! </h1>
                    </div>
                </div>
				
				<!-- /. ROW  -->
				
				
				<div class="col-md-4">
					<div class="panel panel-info">
						<div class="panel-heading">
							<i class="fa fa-bell fa-fw"></i>Job Details
						</div>

						<div class="panel-body">
							<div class="list-group">
							
								<?php
    
									if (isset($_POST['submit']))
									{
										if (isset($_POST['job_id']) && isset($_POST['student_id']) && isset($_POST['announce_time']))
										{
											$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
											$query = 
											"UPDATE Announcement " . 
											"SET announce_status = 1 " . 
											"WHERE student_id = " . $_POST['student_id'] . " AND job_id = " . $_POST['job_id'] . " AND announce_time = '" . $_POST['announce_time'] . "';";
											// echo $query;
											mysqli_query($dbc, $query);
											mysqli_close($dbc);
										}
										else if (isset($_POST['job_id']) && isset($_POST['student_id']) && isset($_POST['friend_id']) && isset($_POST['forward_time']))
										{
											$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
											$query = 
											"UPDATE Forward " . 
											"SET forward_status = 1 " . 
											"WHERE student_id = " . $_POST['student_id'] . " AND job_id = " . $_POST['job_id'] . " AND friend_id = " . $_POST['friend_id'] . " AND forward_time = '" . $_POST['forward_time'] . "';";
											// echo $query;
											mysqli_query($dbc, $query);
											mysqli_close($dbc);
										}

										

										if ($_POST['submit'] == 'Apply')
										{
											// echo $job_id;
											$job_id = $_POST['job_id'];
											$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
											$query = 
											"INSERT INTO Application (student_id, job_id, apply_time) " . 
											"VALUES ($student_id, $job_id, NOW()); ";
											echo $query;
											mysqli_query($dbc, $query);
											echo '<h2> Application sent </h2>';
											mysqli_close($dbc);
										}
										else if ($_POST['submit'] == 'Details')
										{
											$job_id = $_POST['job_id'];
											echo '<h2> Job Details </h2>';
											$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
											$query = 
											"SELECT company_id, job_id, company_name, industry, company_location, job_location, title, salary, publish_time, job_description, company_description " . 
											"FROM Job NATURAL JOIN Company " . 
											"WHERE job_id = $job_id";
											$data = mysqli_query($dbc, $query);
											$record = mysqli_fetch_array($data);
											
											echo $job_id;


											echo '
											<a href="#" class="list-group-item">
												<i class="fa fa-twitter fa-fw"></i>Title
											<span class="pull-right text-muted small"><em>'. $record['title'] .'</em>
											</span>
											</a>
											
											<a href="#" class="list-group-item">
												<i class="fa fa-envelope fa-fw"></i>company_name
											<span class="pull-right text-muted small"><em>'. $record['company_name'] .'</em>
											</span>
											</a>
											
											<a href="#" class="list-group-item">
												<i class="fa fa-tasks fa-fw"></i>publish_time
											<span class="pull-right text-muted small"><em> '. $record['publish_time'] .'</em>
											</span>
											</a>
											<a href="#" class="list-group-item">
												<i class="fa fa-upload fa-fw"></i>job_location
											<span class="pull-right text-muted small"><em>'. $record['job_location'] .'</em>
											</span>
											</a>
											<a href="#" class="list-group-item">
												<i class="fa fa-bolt fa-fw"></i>salary
											<span class="pull-right text-muted small"><em>'. $record['salary'] .'</em>
											</span>
											</a>

											<a href="JobDetails.php" class="btn btn-info btn-block">Apply Now</a>';
											
										}
										else if ($_POST['submit'] == "Forward")
										{   
											$friend_id = $_POST['friend_id'];
											$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
											$query = 
											"INSERT INTO Forward (student_id, friend_id, job_id, forward_time) " . 
											"VALUES ($student_id, $friend_id, $job_id, NOW()); ";

											// echo $query;

											mysqli_query($dbc, $query);

											echo '<h2> Job Message Forward to Friend';
											mysqli_close($dbc);
										}
										else if ($_POST['submit'] == "Apply Now")
										{
											$job_id = $_POST['job_id'];
											$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
											$query = 
											"INSERT INTO Application (student_id, job_id, apply_time) " . 
											"VALUES ($student_id, $job_id, NOW()); ";
											mysqli_query($dbc, $query);
											echo '<h2> Application sent </h2>';
											mysqli_close($dbc);
										}
									}
								?>
							</div>
						</div>

					</div>
				</div>
														

				<?php    
				if (isset($_POST['submit']))
				{
					if (isset($_POST['job_id']) && isset($_POST['student_id']) && isset($_POST['announce_time']))
					{
						$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
						$query = 
						"UPDATE Announcement " . 
						"SET announce_status = 1 " . 
						"WHERE student_id = " . $_POST['student_id'] . " AND job_id = " . $_POST['job_id'] . " AND announce_time = '" . $_POST['announce_time'] . "';";
						// echo $query;
						mysqli_query($dbc, $query);
						mysqli_close($dbc);
					}
					else if (isset($_POST['job_id']) && isset($_POST['student_id']) && isset($_POST['friend_id']) && isset($_POST['forward_time']))
					{
						$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
						$query = 
						"UPDATE Forward " . 
						"SET forward_status = 1 " . 
						"WHERE student_id = " . $_POST['student_id'] . " AND job_id = " . $_POST['job_id'] . " AND friend_id = " . $_POST['friend_id'] . " AND forward_time = '" . $_POST['forward_time'] . "';";
						// echo $query;
						mysqli_query($dbc, $query);
						mysqli_close($dbc);
					}

					$job_id = $_POST['job_id'];
					if ($_POST['submit'] == 'Apply')
					{
						// echo $job_id;
						$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
						$query = 
						"INSERT INTO Application (student_id, job_id, apply_time) " . 
						"VALUES ($student_id, $job_id, NOW()); ";
						mysqli_query($dbc, $query);
						mysqli_close($dbc);
					}
					else if ($_POST['submit'] == 'Details')
					{
						$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
						$query = 
						"SELECT company_id, job_id, company_name, industry, company_location, job_location, title, salary, publish_time, job_description, company_description " . 
						"FROM Job NATURAL JOIN Company " . 
						"WHERE job_id = $job_id";
						$data = mysqli_query($dbc, $query);
						$record = mysqli_fetch_array($data);
						echo '
						<div class="row" style="padding-bottom: 100px; `">
							<div class="col-md-6">
								<div class="panel panel-back noti-box">
									<div class="text-box">
										<p class="main-text">job_description </p>
										<p>
										'.$record['job_description'].'
										</p>
									</div>
								</div>
							</div>
						</div>';
					}
				}
				?>	

                <!--/.ROW-->
				
				
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
					
					<tbody>						
						<?php
							if (isset($_POST['submit']))
							{
								if (isset($_POST['job_id']) && isset($_POST['student_id']) && isset($_POST['announce_time']))
								{
									$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
									$query = 
									"UPDATE Announcement " . 
									"SET announce_status = 1 " . 
									"WHERE student_id = " . $_POST['student_id'] . " AND job_id = " . $_POST['job_id'] . " AND announce_time = '" . $_POST['announce_time'] . "';";
									// echo $query;
									mysqli_query($dbc, $query);
									mysqli_close($dbc);
								}
								else if (isset($_POST['job_id']) && isset($_POST['student_id']) && isset($_POST['friend_id']) && isset($_POST['forward_time']))
								{
									$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
									$query = 
									"UPDATE Forward " . 
									"SET forward_status = 1 " . 
									"WHERE student_id = " . $_POST['student_id'] . " AND job_id = " . $_POST['job_id'] . " AND friend_id = " . $_POST['friend_id'] . " AND forward_time = '" . $_POST['forward_time'] . "';";
									// echo $query;
									mysqli_query($dbc, $query);
									mysqli_close($dbc);
								}

								$job_id = $_POST['job_id'];
								if ($_POST['submit'] == 'Apply')
								{
									// echo $job_id;
									$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
									$query = 
									"INSERT INTO Application (student_id, job_id, apply_time) " . 
									"VALUES ($student_id, $job_id, NOW()); ";
									mysqli_query($dbc, $query);
									mysqli_close($dbc);
								}
								else if ($_POST['submit'] == 'Details')
								{
									$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');
									$query = 
									"SELECT company_id, job_id, company_name, industry, company_location, job_location, title, salary, publish_time, job_description, company_description " . 
									"FROM Job NATURAL JOIN Company " . 
									"WHERE job_id = $job_id";
									$data = mysqli_query($dbc, $query);
									$record = mysqli_fetch_array($data);

							//list friends
									
									$query = 
									"SELECT * " . 
									"FROM Student  " . 
									"WHERE student_id != $student_id AND ( " . 
									"student_id IN  " . 
									"(	SELECT student_id  " . 
									"   FROM friend  " . 
									"   WHERE (student_id = $student_id OR friend_id = $student_id) AND status = 'Approved' " . 
									") OR  " . 
									"student_id IN  " . 
									"(  SELECT friend_id  " . 
									"   FROM Friend  " . 
									"   WHERE (student_id = $student_id OR friend_id = $student_id) AND status = 'Approved' " . 
									")); ";
									// echo $query;
									$data = mysqli_query($dbc, $query);
									if (mysqli_num_rows($data) != 0)
									{
										echo '<h2> Friend List </h2>';
										echo '<thead>
											<tr>
												<th>Name</th>
												<th>Email</th>
												<th>Action.</th>														
											</tr>
										</thead>';

										while ($record = mysqli_fetch_array($data))
										{
											echo '<tr>';
											echo '<td>' . $record['student_name'] . '</td>';
											echo '<td>' . $record['student_email'] . '</td>';
											echo '<td>';
											echo '<form method="POST" action="JobDetails.php">';
											echo '<input type="submit" class="btn btn-success" name="submit" value="Forward"/>';
											echo '<input type="hidden" name="job_id" value=' . $job_id . '>';
											echo '<input type="hidden" name="friend_id" value=' . $record['student_id'] . '>';
											echo '</td>';
											echo '<form>';
											echo '</tr>';
										}
										mysqli_close($dbc);
									}
								}
							}
						?>
					</tbody>
					</table>
					</div>
					</div>
				</div>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->


    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>

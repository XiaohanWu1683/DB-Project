<?php
    require_once('connection.php');
    session_start();
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
?>

<?php
    if (isset($_POST['submit']))
    {
        if ($_POST['submit'] == 'Unfriend')
        {
            $friend_id = $_POST['friend_id'];
            $student_email = $_POST['student_email'];
            $student_name = $_POST['student_name'];
            
            echo '<h2> Are you sure you want to delete friend? </h2>';
            echo '<p><strong>Name: </strong>' . $student_name . '<br /><strong>Email: </strong>' . $student_email;
            echo '<form method="post" action="deletefriend.php">';
            echo '  <input type="radio" name="confirm" value="Yes" /> Yes ';
            echo '  <input type="radio" name="confirm" value="No" checked="checked" /> No <br />';
            echo '  <input type="submit" value="Submit" name="submit" />';
            echo '  <input type="hidden" name="friend_id" value="' . $friend_id . '" />';
            echo '</form>';
        }
        else if ($_POST['submit'] == 'Submit' && $_POST['confirm'] == 'Yes')
        {
            $friend_id = $_POST['friend_id'];
            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 
            $query = 
            "DELETE FROM Friend " . 
            "WHERE (friend_id = $student_id AND student_id = $friend_id) OR (friend_id = $friend_id AND student_id = $student_id);";
            mysqli_query($dbc, $query);
            echo 'this is the new shit';
            mysqli_close($dbc);

            echo '<p> Friend Reomved </p>';
        }
    }
    echo '<a href="friendpage.php"> << Back to Friend </a>';  
?>
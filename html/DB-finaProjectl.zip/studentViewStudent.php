
<?php
    require_once('connection.php');
    session_start();
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Students Search</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>

        #topContainer
        {
            background-image: url("images/companybackground.jpg");
            height:975px;
            width:100%;
            background-size:cover;
        }

        #informationRow
        {
            margin-top:100px;
        }
        #informationform
        {
            margin-top:20px;
        }
		
		#resultform
        {
			margin-top:-200px;
			margin-left:1000px;
		}

        .whiteBackground{
            margin-right:10px;
            padding:20px;
            background-color: hsla(240, 20%, 95%, 0.8);
            border-radius: 20px;
        }

    </style>
</head>
<body>

<div class="container" id="topContainer">
    <div class="row" id="informationRow">
		<div class="col-md-6 col-md-offset-1 whiteBackground" id="informationform">
<?php
    if (isset($_POST['submit']) && $_POST['submit'] == 'Details')
    {
        $friend_id = $_POST['student_id'];
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die('db connection error #3');
        
        $query = "SELECT * FROM Student WHERE student_id = $friend_id; ";
        $data = mysqli_query($dbc, $query);
        $record = mysqli_fetch_array($data);

        $student_name = $record['student_name'];
        $student_email = $record['student_email'];
        $student_phone = $record['student_phone'];
        $major = $record['major'];
        $university = $record['university'];
        $resume = $record['resume'];
        $gpa = $record['gpa'];
        $privacy = $record['privacy'];

        echo '<h2> Student Info </h2>';

        echo '<strong> Student Name: </strong>' . $student_name . '</br>';
        echo '<strong> Email: </strong>' . $student_email . '</br>';
        echo '<strong> Phone: </strong>' . $student_phone . '</br>';
        echo '<strong> University: </strong>' . $university . '</br>';
        echo '<strong> major: </strong>' . $major . '</br>';

        if ($privacy != 'Private')
        {
            $query = 
            "SELECT * " . 
            "FROM Friend " . 
            "WHERE (student_id = $student_id AND friend_id = " . $record['student_id'] . " AND status = 'Approved') OR " . 
            "(friend_id = $student_id AND student_id = " . $record['student_id'] . " AND status = 'Approved');";



            $data = mysqli_query($dbc, $query);
            if (mysqli_num_rows($data))
            {
                echo '<strong> GPA: </strong>' . $gpa . '</br>';
                echo '<strong> Resume: </strong> </br>' . $resume . '</br>';
            }
        } 
        mysqli_close($dbc);
    }
?>  
        <a href="friendpage.php"> << Back </a>
		</div>
	</div>
</div>

</body>
</html>
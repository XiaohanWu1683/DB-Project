<?php
    session_start();
    require_once('connection.php');
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
    $msg = '';
?>




<?php
    
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    if (isset($_POST['submit']))
    {    
        if (isset($_POST['registerpassword']))
        {
            // echo $_POST['privacy'];
           
            if (!empty($_POST['registername']))
            {
                $_SESSION['student_name'] = $_POST['registername'];
                $query = "UPDATE Student SET student_name = '" . $_POST['registername'] . "' WHERE student_id = $student_id; ";
                mysqli_query($dbc, $query);
            }

            if (!empty($_POST['registerpassword']))
            {
                $query = "UPDATE Student SET student_password = SHA('" . $_POST['registerpassword'] . "') WHERE student_id = $student_id; ";
                mysqli_query($dbc, $query);
            }

            if (!empty($_POST['registerphone']))
            {
                $query = "UPDATE Student SET student_phone = '" . $_POST['registerphone'] . "' WHERE student_id = $student_id; ";
                mysqli_query($dbc, $query);
            }

            if (!empty($_POST['registermajor']))
            {
                $query = "UPDATE Student SET major = '" . $_POST['registermajor'] . "' WHERE student_id = $student_id; ";
                mysqli_query($dbc, $query);
            }

            if (!empty($_POST['registeruniver']))
            {
                $query = "UPDATE Student SET university = '" . $_POST['registeruniver'] . "' WHERE student_id = $student_id; ";
                mysqli_query($dbc, $query);
            }
        
            if (!empty($_POST['registergpa']))
            {
                $query = "UPDATE Student SET gpa = " . $_POST['registergpa'] . " WHERE student_id = $student_id; ";
                mysqli_query($dbc, $query);
            }

            if (!empty($_POST['registerresume']))
            {
                $query = "UPDATE Student SET resume = '" . $_POST['registerresume'] . "' WHERE student_id = $student_id; ";
                mysqli_query($dbc, $query);
            }
            
            $query = "UPDATE Student SET privacy = '" . $_POST['privacy'] . "' WHERE student_id = $student_id; ";
            mysqli_query($dbc, $query);
        }
        else
            $msg = 'password cannot be empty';
    }


    mysqli_close($dbc);
?>




<!-- Editstudent -->

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>home</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Jobster</a>
            </div>

            <div class="header-right">
				<!--显示未读消息数量-->
                <a href="studentjobnot.php" class="btn btn-info" title="New Jobs"><b>
					<?php
                        echo $_SESSION['jobs_unread'];
					?>
				</b><i class="fa fa-envelope-o fa-2x"></i></a>
				
				<!--显示未读消息数量-->
                <a href="studentfriendmes.php" class="btn btn-primary" title="New Messages"><b>
					<?php
                        echo $_SESSION['msg_unread'];
					?>
				</b><i class="fa fa-bars fa-2x"></i></a>
				
				<a href="logout.php" class="btn btn-danger" title="Logout"><i class="fa fa-exclamation-circle fa-2x"></i></a>
            </div>
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="assets/img/user.png" class="img-thumbnail" />

                            <div class="inner-text">
                                <?php
									echo '<font color=white>' . $student_name . '</font>';
								?>
                            <br />
                                <small>Student </small>
                            </div>
                        </div>

                    </li>


                    <li>
                        <a href="studenthome.php"><i class="fa fa-dashboard "></i>Home</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-yelp "></i>Message Box <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="studentfriendmes.php"><i class="fa fa-coffee"></i>Friend Messages</a>
                            </li>
                            <li>
                                <a href="studentjobnot.php"><i class="fa fa-flash "></i>Job Notification</a>
                            </li>
                             <li>
                                <a href="studentsent.php"><i class="fa fa-key "></i>Send</a>
                            </li>                           
                        </ul>
                    </li>
                    <li>
                        <a href="jobsearch.php"><i class="fa fa-flash "></i>Job Search </a>
                        
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-bicycle "></i>Social <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                           
                             <li>
                                <a href="friendpage.php"><i class="fa fa-desktop "></i>Friends </a>
                            </li>
                             <li>
                                <a href="followedcompany.php"><i class="fa fa-code "></i>Followed Company</a>
                            </li>
                        </ul>
                    </li>
                      <li>
                        <a  class="active-menu" href="editstudent.php"><i class="fa fa-anchor "></i>Edit Profile</a>
                    </li>
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Profile</h1>
                        <h1 class="page-subhead-line">Edit your profile. </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Edit Area
                            </div>

                            <div class="panel-body">
                                <div style="margin-top: 20px;">
                                 
									<form id="editform" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
				
										<div class="form-group">
											<label for="registername">User Name:</label>
											<input type="text" class="form-control" placeholder="User Name" name="registername" id="registername"/>
										</div>

										
										
										<div class="form-group">
											<label for="registerphone">Phone number:</label>
									  
										<input type="text" class="form-control" placeholder="Phone number" name="registerphone" id="registerphone"/>
										</div>
										
										<div class="form-group">
											<label for="registermajor">Major:</label>
											<input type="text" class="form-control" placeholder="Major name" name="registermajor" id="registermajor"/>
										</div>
										
										<div class="form-group">
											<label for="registeruniver">University name:</label>
											<input type="text" class="form-control" placeholder="University name" name="registeruniver" id="registeruniver"/>
										</div>
										
										<div class="form-group">
											<label for="registergpa">GPA:(have to be valid number)</label>
											<input type="float" class="form-control" placeholder="GPA" name="registergpa" id="registergpa"/>
										</div>
										
										<div class="form-group">
											<label for="registerresume">Resume:</label>
											<input type="text" class="form-control" placeholder="Resume" name="registerresume" id="registerresume"/>
										</div>
										
                                        <label for="privacy">Priacy:</label>
                                        <select name="privacy" form="editform">
                                            <option value="Private">Private</option>
                                            <option value="Protected">Protected</option>
                                            <option value="Public">Public</option>
                                        </select> 

                                        <div class="form-group">
											<label for="registerpassword">Password <font color=red>*</font>:</label>
											<input type="password" class="form-control" placeholder="Password" name="registerpassword" id="registerpassword"/>
										</div>
										<br/>
										<input type="submit" class="btn btn-success" name="submit" value="Submit"/>
                                    </form>
                                    


                                            
                                                                 
								</div>
                            </div>
                        </div>
                    </div>
				</div>


    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>

<?php echo $msg; ?>

</html>
<?php
// Define database connection constants
    define('DB_HOST', 'localhost:3306');
    define('DB_USER', 'root');
    define('DB_PASSWORD', 'pc450471');
    define('DB_NAME', 'jobster');
?>

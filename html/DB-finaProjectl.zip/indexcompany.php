<?php
    session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Jobster Company Homepage</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>

        #topContainer
        {
            background-image: url("images/companyback.jpg");
            height:975px;
            width:100%;
            background-size:cover;
        }
        #registerRow
        {
            margin-top:200px;
        }
        #registerform
        {
            margin-top:20px;
        }
        .whiteBackground
        {
            margin-right:10px;
            padding:20px;
            background-color: hsla(240, 20%, 95%, 0.8);
            border-radius: 20px;
        }

    </style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top" id="topBar">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbarlink" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
				<span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
		
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbarlink">
            <ul class="nav navbar-nav ">
				<li><a href="index.php">Students</a></li>
                <li class="active"><a href="indexcompany.php">Companies<span class="sr-only">(current)</span></a></li>
				<!-- <li><a href="about.php">About</a></li>
                <li><a href="Developer.php">Developer</a></li> -->
            </ul>
			
            <form class="navbar-form navbar-right" method="post">
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Company Email" name="logincompanyemail"/>
                </div>

                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" name="logincompanypassword"/>
                </div>
                <input type="submit" class="btn btn-success" name="login" value="Log in"/>
            </form>

        </div>
    </div>
</nav>



<div class="container" id="topContainer">
    <div class="row" id="registerRow">
        <div class="col-md-4 col-md-offset-1 whiteBackground" id="registerform">
		<h1> Company Register</h1>
            <form method="post" action="indexcompany.php">

                <div class="form-group">
                    <label for="registercompanyname">Company Name:</label>
                    <input type="text" class="form-control" placeholder="Company Name" name="registercompanyname" id="registercompanyname"/>
                </div>

                <div class="form-group">
                    <label for="registercompanyemail">Email:(You will use it as login account)</label>
                    <input type="email" class="form-control" placeholder="Email" name="registercompanyemail" id="registercompanyemail"/>
                </div>

                <div class="form-group">
                    <label for="registercompanypassword">Password:</label>
                    <input type="password" class="form-control" placeholder="Password" name="registercompanypassword" id="registercompanypassword"/>
                </div>
				
				<div class="form-group">
                    <label for="registercompanylocation">Company Location:</label>
                    <input type="text" class="form-control" placeholder="Company Location" name="registercompanylocation" id="registercompanylocation"/>
                </div>
				
				<div class="form-group">
                    <label for="registercompanyindustry">Company Industry:</label>
                    <input type="text" class="form-control" placeholder="Company Industry" name="registercompanyindustry" id="registercompanyindustry"/>
                </div>


                <div class="form-group">
                    <label for="registercompanyindustry">Company Description:</label>
                    <input type="text" class="form-control" placeholder="Company Description" name="registercompanydescription" id="registercompanydescription"/>
                </div>
				
                <input type="submit" class="btn btn-success" name="signup" value="Sign up"/>

            </form>

        </div>
    </div>
</div>



<div>


    <?php // sign in

        if (!isset($_SESSION["company_id"]))
        {
            require_once('connection.php');
            // clear error message
            $error_msg = '';
            if (isset($_POST['login']))
            {
                $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die('db connection error # 5');
                $login_emial = mysqli_real_escape_string($dbc, trim($_POST['logincompanyemail']));
                $login_pasword = mysqli_escape_string($dbc, trim($_POST['logincompanypassword']));

                if (!empty($login_emial) && !empty($login_pasword))
                {
                    $query = 
                    "SELECT company_id, company_email, company_name " . 
                    "FROM Company " . 
                    "WHERE company_email = '$login_emial' AND company_password = SHA('$login_pasword'); ";

                    $msg =  $query;
                    
                    $data = mysqli_query($dbc, $query);
                    if (mysqli_num_rows($data) == 1)
                    {
                        // valid email and pwd
                        $record = mysqli_fetch_array($data);
                        $_SESSION['company_id'] = $record['company_id'];
                        $_SESSION['company_email'] = $record['company_email'];
                        $_SESSION['company_name'] = $record['company_name'];

                        echo '<form name="front" action="companyhome.php" method="POST">';
                        echo '   <input type="hidden" name="company_id" value="' . $_SESSION['company_id'] . '">';
                        echo '</form>';
                        echo '<script type="text/javascript">';
                        echo '   document.front.submit();';
                        echo '</script>';

                    }
                    else $error_msg = 'Invalid email or pwd';
                }
                else $error_msg = 'Must enter all the information';
            }
        }
        else
        {
            echo '<form name="front" action="companyhome.php" method="POST">';
            echo '   <input type="hidden" name="student_id" value="' . $_SESSION['student_id'] . '">';
            echo '</form>';
            echo '<script type="text/javascript">';
            echo '   document.front.submit();';
            echo '</script>';
        }
    ?>

</div>


<div>
    <?php //sign up

        if (isset($_POST['signup']))
        {
            // echo '???';
            require_once('connection.php');
            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die('db connection error #3');

            $company_name = mysqli_real_escape_string($dbc, trim($_POST['registercompanyname']));
            $company_password = mysqli_real_escape_string($dbc, trim($_POST['registercompanypassword']));
            $company_email = mysqli_real_escape_string($dbc, trim($_POST['registercompanyemail']));
            $company_location = mysqli_real_escape_string($dbc, trim($_POST['registercompanylocation']));
            $industry = mysqli_real_escape_string($dbc, trim($_POST['registercompanyindustry']));
            $company_description = mysqli_real_escape_string($dbc, trim($_POST['registercompanydescription']));

            if (!empty($company_name) && !empty($company_password) && !empty($company_email) && !empty($company_location) && !empty($industry) && !empty($company_description))
            {
                $query = 
                "SELECT * FROM Company " . 
                "WHERE company_email = '$company_email'; ";

                // echo $query;

                $data = mysqli_query($dbc, $query);
                
                if (!mysqli_num_rows($data))
                {
                    # email is unique
                    $query = 
                    "INSERT INTO Company (company_name, company_password, company_email, company_location, industry, company_description) " . 
                    "VALUES ('$company_name', SHA('$company_password'), '$company_email', '$company_location', '$industry', '$company_description'); ";
                    // echo $query;
                    mysqli_query($dbc, $query);
                    echo '<p> Welcome to Jobster! ';
                    echo 'You are now ready to log in. </p>';

                    mysqli_close($dbc);
                    exit();
                }
                else $error_msg = 'an account already occur.';
            }
            else $error_msg = 'critical data missing';
            mysqli_close($dbc);
            $msg = 'thi si sht era ';
        }

        // 

    ?>
</div>

</body>
</html>

<h3> <?php echo $msg; ?> </h3>

<?php
    require_once('connection.php');
    session_start();
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
?>

<?php
    if (isset($_POST['submit']))
    {
        if ($_POST['submit'] == 'Unfollow')
        {
            $company_id = $_POST['company_id'];
            $company_name = $_POST['company_name'];
            $company_email = $_POST['company_email'];
            
            echo '<h2> Are you sure you want to unfollow the company? </h2>';
            echo '<p><strong>Name: </strong>' . $company_name . '<br /><strong>Email: </strong>' . $company_email;
            echo '<form method="post" action="unfollowCompany.php">';
            echo '  <input type="radio" name="confirm" value="Yes" /> Yes ';
            echo '  <input type="radio" name="confirm" value="No" checked="checked" /> No <br />';
            echo '  <input type="submit" value="Submit" name="submit" />';
            echo '  <input type="hidden" name="company_id" value="' . $company_id . '" />';
            echo '</form>';
        }
        else if ($_POST['submit'] == 'Submit' && $_POST['confirm'] == 'Yes')
        {
            $company_id = $_POST['company_id'];
            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 
            $query = 
            "DELETE FROM Follow " . 
            "WHERE student_id = $student_id AND company_id = $company_id; ";
            mysqli_query($dbc, $query);
            mysqli_close($dbc);

            echo '<p> Company Unfollowed </p>';
        }
    }
    echo '<a href="friendpage.php"> << Back to Friend </a>';  
?>
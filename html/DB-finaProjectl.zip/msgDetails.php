<?php
    session_start();
    require_once('connection.php');
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Messsage Details</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>

        #topContainer
        {
            background-image: url("images/companybackground.jpg");
            height:975px;
            width:100%;
            background-size:cover;
        }

        #informationRow
        {
            margin-top:100px;
        }
        #informationform
        {
            margin-top:20px;
        }
		
		#resultform
        {
			margin-top:-200px;
			margin-left:1000px;
		}

        .whiteBackground{
            margin-right:10px;
            padding:20px;
            background-color: hsla(240, 20%, 95%, 0.8);
            border-radius: 20px;
        }

    </style>
</head>
<body>
<div class="container" id="topContainer">
    <div class="row" id="informationRow">
		<div class="col-md-6 col-md-offset-1 whiteBackground" id="informationform">
<?php
    if (isset($_POST['submit']))
    {
        $msg_from = $_POST['msg_from'];
        $msg_to = $_POST['msg_to'];
        $msg_time = $_POST['msg_time'];

        if (!empty($msg_from) && !empty($msg_to) && !empty($msg_time))
        {
            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 
            $query = 
            "UPDATE Message " .
            "SET msg_status = 1 ".
            "WHERE msg_from = $msg_from AND msg_to = $msg_to AND msg_time = '" . $msg_time . "';";
            // echo $query;

            mysqli_query($dbc, $query);

            $query = 
            "SELECT * FROM Student " . 
            "WHERE student_id = $msg_from";
            // echo $query;
            $data = mysqli_query($dbc, $query);
            $record = mysqli_fetch_array($data);
            echo '<strong> From: </strong>';
            echo $record['student_name'] . '</br>';
            echo '<strong> Time: </strong>';
            echo $msg_time . '</br>';
            echo '<strong> Content: </strong> </br>';
            echo $_POST['content'];

            mysqli_close($dbc);

        }
    }
?>
        <a href="studentfriendmes.php"> << Back </a>
		</div>
	</div>
</div>

</body>
</html>
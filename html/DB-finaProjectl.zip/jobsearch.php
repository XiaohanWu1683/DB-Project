<?php
    session_start();
    require_once('connection.php');
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
?>

<!-- 学生主页，Homepage -->

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>home</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Jobster</a>
            </div>

            <div class="header-right">
				<!--显示未读消息数量-->
                <a href="studentjobnot.php" class="btn btn-info" title="New Jobs"><b>
					<?php
                        echo $_SESSION['jobs_unread'];
					?>
				</b><i class="fa fa-envelope-o fa-2x"></i></a>
				
				<!--显示未读消息数量-->
                <a href="studentfriendmes.php" class="btn btn-primary" title="New Messages"><b>
					<?php
                        echo $_SESSION['msg_unread'];
					?>
				</b><i class="fa fa-bars fa-2x"></i></a>
				
				<a href="logout.php" class="btn btn-danger" title="Logout"><i class="fa fa-exclamation-circle fa-2x"></i></a>
            </div>
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="assets/img/user.png" class="img-thumbnail" />

                            <div class="inner-text">
                                <?php
									echo '<font color = white>' . $_SESSION['student_name'] . '</font>';
								?>
                            <br />
                                <small>Student </small>
                            </div>
                        </div>

                    </li>


                    <li>
                        <a href="studenthome.php"><i class="fa fa-dashboard "></i>Home</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-yelp "></i>Message Box <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="studentfriendmes.php"><i class="fa fa-coffee"></i>Friend Messages</a>
                            </li>
                            <li>
                                <a href="studentjobnot.php"><i class="fa fa-flash "></i>Job Notification</a>
                            </li>
                             <li>
                                <a href="studentsent.php"><i class="fa fa-key "></i>Send</a>
                            </li>                           
                        </ul>
                    </li>
                    <li>
                        <a class="active-menu" href="jobsearch.php"><i class="fa fa-flash "></i>Job Search </a>
                        
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-bicycle "></i>Social <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                           
                             <li>
                                <a href="friendpage.php"><i class="fa fa-desktop "></i>Friends </a>
                            </li>
                             <li>
                                <a href="followedcompany.php"><i class="fa fa-code "></i>Followed Company</a>
                            </li>
                             
                           
                        </ul>
                    </li>
                      <li>
                        <a href="editstudent.php"><i class="fa fa-anchor "></i>Edit Profile</a>
                    </li>
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Jobs</h1>
                        <h1 class="page-subhead-line">Good luck! </h1>
                    </div>
                </div>
				
				<!-- /. ROW  -->


                <div class="row">

                    <div class="col-md-8">
                        <div class="list-group">
                            <a href="#" class="list-group-item active">
                                <p class="list-group-item-text" style="line-height: 30px;">
									<form method="post" action="jobsearch.php">
										<div class="form-group">
											<label for="jobkeyword">Job Search:</label>
											<input type="text" class="form-control" placeholder="Please enter job name or company name" name="jobkeyword" id="jobkeyword"/>
										</div>

										<input type="submit" class="btn btn-success" name="submit" value="Search"/>
									</form>
                                </p>
                            </a>
                        </div>
                        <br />
                        
                    </div>
                    
                </div>
                <div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
					
					<tbody>						
						<?php
							if (isset($_POST['submit']))
							{
								if ($_POST['submit'] == 'Search')
								{
									$keyword = $_POST['jobkeyword'];
									$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) or die ('db connection error');                      
									$query = 
									"SELECT company_id, job_id, company_name, industry, job_location, title, salary, publish_time " . 
									"FROM job NATURAL JOIN company " . 
									"WHERE title LIKE'%$keyword%' OR job_location LIKE'%$keyword%' OR background_req LIKE '%$keyword%' OR job_description LIKE '%$keyword%' OR company_name LIKE '%$keyword%' OR company_email = '$keyword' OR industry LIKE '%$keyword%'; ";
									
									// echo $query;
									$data = mysqli_query($dbc, $query);

									if (mysqli_num_rows($data) != 0)
									{
										echo '<thead>
											<tr>
												<th>Title</th>
												<th>Company</th>
												<th>Location.</th>
												<th>Salary</th>
												<th>Publish Time</th>
												<th>Action</th>
											</tr>
										</thead>';

										while ($record = mysqli_fetch_array($data))
										{
											echo '<tr>';
											echo '<td>' . $record['title'] . '</td>';
											echo '<td>' . $record['company_name'] . '</td>';
											echo '<td>' . $record['job_location'] . '</td>';
											echo '<td>' . $record['salary'] . '</td>';
											echo '<td>' . $record['publish_time'] . '</td>';
											echo '<td>';
											echo '<form method="POST" action="JobDetails.php">';
											echo '<input type="submit" class="btn btn-success" name="submit" value="Apply"/>';
											echo '<input type="submit" class="btn btn-success" name="submit" value="Details"/>';
                                            echo '<input type="hidden" name="job_id" value=' . $record['job_id'] . '>';
                                            echo $record['job_id'];
											echo '</td>';
											echo '</form>';
                                            echo '</tr>';
                                            
										}
									}
									else echo 'No result found';
								}
							}
						?>
					</tbody>
					</table>
					</div>
					</div>
				</div>
                <!--/.ROW-->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->


    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>

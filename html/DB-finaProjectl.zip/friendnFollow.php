<?php
    require_once('connection.php');
    session_start();
    $student_id = $_SESSION['student_id'];
    $student_name = $_SESSION['student_name'];
?>

<?php
    if (isset($_POST['submit']))
    {
        if ($_POST['submit'] == 'Friend')
        {
            $friend_id = $_POST['friend_id'];
            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 
            $query =  
            "INSERT INTO Friend (student_id, friend_id, friend_time, status) " . 
            "VALUES ($student_id, $friend_id, NOW(), 'Pending'); ";
            // echo $query;
            mysqli_query($dbc, $query);
            mysqli_close($dbc);
            echo '<p> Friend request sent </p>';
        }
        else if ($_POST['submit'] == 'Follow')
        {
            $company_id = $_POST['company_id'];
            $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME); 
            $query =  
            "INSERT INTO Follow (student_id, company_id) " . 
            "VALUES ($student_id, $company_id) ; ";
            // echo $query;
            mysqli_query($dbc, $query);
            mysqli_close($dbc);
            echo '<p> Company Followed </p>';
        }
    }
    echo '<a href="friendpage.php"> << Back to Friend </a>';
?>